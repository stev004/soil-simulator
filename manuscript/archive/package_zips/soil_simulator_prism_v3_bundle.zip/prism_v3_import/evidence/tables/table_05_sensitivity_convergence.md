# Preview: table_05_sensitivity_convergence

Generated from the adjacent CSV for human inspection. The CSV is canonical.

| previous_base_sample_size | current_base_sample_size | maximum_absolute_s1_change | maximum_absolute_st_change | s1_rank_correlation | st_rank_correlation | mean_ci_width | unstable_fraction | negative_fraction | converged | units | source_path | audit_status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 128 | 256 | 0.2224078177811703 | 0.18846367764774508 | 0.9119779777983956 | 0.9918063248086033 | 0.21563179147961486 | 0.075 | 0.04642857142857143 | False | dimensionless except sample counts | outputs/phase97_v0.9.7/sensitivity_convergence_manifest.json | not converged; diagnostic only |
| 256 | 512 | 0.1411858940350048 | 0.13382703006420793 | 0.912953601733165 | 0.9881837876873083 | 0.15651542835275162 | 0.025 | 0.04285714285714286 | False | dimensionless except sample counts | outputs/phase97_v0.9.7/sensitivity_convergence_manifest.json | not converged; diagnostic only |
| 512 | 1024 | 0.12198870701977597 | 0.11231133335646482 | 0.9350920743816574 | 0.9974228200036107 | 0.11010157797502626 | 0.017857142857142856 | 0.017857142857142856 | False | dimensionless except sample counts | outputs/phase97_v0.9.7/sensitivity_convergence_manifest.json | not converged; diagnostic only |
